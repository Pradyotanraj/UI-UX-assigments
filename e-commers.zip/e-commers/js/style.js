let product= [{
    "Id": 1,
    "image": "OIP.jfif",
    "Name":"Casual shoe",
    "Price":123
    },
    {
    "Id": 2,
    "image": "4.jpg",
    "Name":"H&M Blue jeans",
    "Price":321
    },
    {
        "Id": 3,
        "image": "mainfront.jpg",
        "Name":"Women Half T-shirt",
        "Price":322
        },
        {

            "Id": 4,
            "image": "1.jpg",
            "Name":"Dark Jeans shirt",
            "Price":321
            }]
let array1=new Array();
localStorage.setItem("allproduct",JSON.stringify(product));   
array1=JSON.parse(localStorage.getItem("allproduct"));
console.log(array1);
  