let user_record = new Array();
user_record = JSON.parse(localStorage.getItem("cart")) ? JSON.parse(localStorage.getItem("cart")):[];

function renderProduct1(){



    let str = "";

    user_record.forEach(product => {

   

        // if(product.falvor == "Vanilla"){

   

        str +=`<div class="card" style="width: 18rem; margin:20px;">

        <img src="${product.image}" class="card-img-top" alt="..." height="200px">

        <div class="card-body">

          <h5 class="card-title">${product.Name}</h5>

          <p class="card-text">${product.Price}$</p>


         <div class="ac">

         <span class="cart" onclick="remove(${product.Id})">Remove</span>

         </div>

        </div>

      </div>`;

    // }

    });

    document.querySelector("#main").innerHTML = str;

    }

    renderProduct1()

    function remove(id){    

        let temp = user_record.filter(item => item.Id != id);
  
        localStorage.setItem("cart",JSON.stringify(temp));
  
        window.location.href ="cart.html";
  
  }