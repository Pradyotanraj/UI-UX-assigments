let data_record = new Array();
  data_record = JSON.parse(localStorage.getItem("allproduct")) ? JSON.parse(localStorage.getItem("allproduct")):[]

  function renderProduct(){



    let str = "";

    data_record.forEach(product => {

   

        // if(product.falvor == "Vanilla"){

   

        str +=`<div class="card" style="width: 18rem; margin:20px;">

        <img src="${product.image}" class="card-img-top" alt="..." height="200px">

        <div class="card-body">

          <h5 class="card-title">${product.Name}</h5>

          <p class="card-text">${product.Price}$</p>

         <div class="ac">

         <a href="#" class=" view" onclick ="getDetail(${product.Id});">View details</a>

         <span class="cart view" onclick="addToCart(${product.Id})">Add To Cart</span>

         </div>

        </div>

      </div>`;

    // }

    });

    console.log(str)

    document.querySelector("#main1").innerHTML = str;
    }
    renderProduct();
    function addToCart(id){

        //  alert("show");

            data_record.forEach(product => {

               

                  if(product.Id == id){




                    let user_record = new Array();



                    user_record = JSON.parse(localStorage.getItem("cart")) ? JSON.parse(localStorage.getItem("cart")):[];

             

                    if(user_record.some((v) =>{return v.Id == id})){

                        alert("Dulicate Data");

                    }else{

                      user_record.push({

                        "Id":product.Id,

                        "Name":product.Name,

                        "image":product.image,

                        "Price":product.Price,


                    })

                     localStorage.setItem("cart",JSON.stringify(user_record));

                     alert("Data Successfully Submitted");

                  window.location.href="cart.html";

                  }        

               }

               });

            }